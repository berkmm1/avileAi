AliveAI v2 - Production-like local demo
=======================================

This package contains a production-minded AliveAI v2 prototype:
- Backend: Express + MongoDB + Redis (BullMQ queue) + JWT auth
- Frontend: Vite + React demo app with login + dashboard
- Worker: processes video jobs and simulates VEO3 calls

Quickstart (requires Docker):
1. Copy .env.example to backend/.env and adjust secrets (or use defaults)
2. Start services with docker-compose:
   docker compose up --build
3. Backend API: http://localhost:4000
   Frontend dev: http://localhost:5173 (or open frontend/dist after build)

Local without Docker:
- Start MongoDB & Redis locally
- In backend: npm install && npm run start
- In frontend: npm install && npm run dev

Notes:
- VEO3 client is a stub. Replace services/veo3Client.js with real API calls for production.
- Use secure secrets and HTTPS in real deployment.
