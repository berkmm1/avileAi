import express from 'express';
import Queue from 'bullmq';
import { createVideoJob } from '../services/veo3Client.js';
import JobModel from '../models/Job.js';
import auth from '../middleware/authMiddleware.js';
import logger from '../utils/logger.js';
import { v4 as uuidv4 } from 'uuid';

const router = express.Router();

// Create queue
import IORedis from 'ioredis';
const connection = new IORedis(process.env.REDIS_URL);
const videoQueue = new Queue.Queue('video-jobs', { connection });

router.post('/create', auth, async (req,res)=>{
  try{
    const { prompt, params } = req.body;
    const jobDoc = await JobModel.create({ userId: req.user.id, prompt, params, status:'queued' });
    // enqueue job with minimal data
    const jobId = uuidv4();
    await videoQueue.add('create', { jobDocId: jobDoc._id.toString(), prompt, params }, { jobId });
    logger.info('Enqueued job '+jobDoc._id);
    return res.json({ jobId: jobDoc._id });
  }catch(e){
    logger.error('video.create error:'+e.message);
    return res.status(500).json({ error:'server error' });
  }
});

router.get('/status/:id', auth, async (req,res)=>{
  try{
    const job = await JobModel.findById(req.params.id);
    if(!job) return res.status(404).json({ error:'not found' });
    return res.json({ status: job.status, resultUrl: job.resultUrl });
  }catch(e){
    return res.status(500).json({ error:'server error' });
  }
});

export default router;
