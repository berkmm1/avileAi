import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import logger from './utils/logger.js';
import authRoutes from './routes/auth.js';
import videoRoutes from './routes/video.js';
import webhookRoutes from './routes/webhook.js';
import bodyParser from 'body-parser';

dotenv.config();
const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.PUBLIC_URL || true }));
app.use(bodyParser.json({limit:'1mb'}));

const limiter = rateLimit({ windowMs: 15*60*1000, max: 200 });
app.use(limiter);

// MongoDB connect
mongoose.connect(process.env.MONGO_URL, { })
  .then(()=> logger.info('MongoDB connected'))
  .catch(err => logger.error('Mongo connect error: '+err.message));

app.get('/health', (req,res)=> res.json({status:'ok'}));
app.use('/auth', authRoutes);
app.use('/video', videoRoutes);
app.use('/webhook', webhookRoutes);

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> logger.info(`AliveAI backend listening on ${PORT}`));
